"""
join每个参数以 \ 拼接
"""
import os
out_path = os.path.join("output", "benchmark", "metric.json")
print(out_path)
# output\benchmark\metric.json