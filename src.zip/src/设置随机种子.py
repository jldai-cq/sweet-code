import random
random.seed(42)